<?php
return [
    'user.passwordResetTokenExpire' => 3600,
];
